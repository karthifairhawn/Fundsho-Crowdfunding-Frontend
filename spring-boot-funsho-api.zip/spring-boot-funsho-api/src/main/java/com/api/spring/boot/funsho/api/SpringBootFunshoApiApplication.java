package com.api.spring.boot.funsho.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootFunshoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootFunshoApiApplication.class, args);
	}

}
